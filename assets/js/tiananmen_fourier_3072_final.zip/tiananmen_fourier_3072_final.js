
'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const canvas = $('stage');
  const ctx = canvas.getContext('2d');
  const playBtn = $('play');
  const restartBtn = $('restart');
  const rateEl = $('rate');
  const seekEl = $('seek');
  const rateText = $('rateText');
  const percent = $('percent');
  const status = $('status');
  const errBox = $('err');
  const svg = document.querySelector('#source svg');

  const FFT_SAMPLES = 8192;
  const HARMONICS = 3072;
  const BUILDING_COLOR = '#c81e1e';
  const STAR_COLOR = '#f3c316';
  const WHEEL_STROKE = 'rgba(25,40,65,0.14)';
  const ARM_STROKE = 'rgba(25,40,65,0.24)';

  let playing = true;
  let progress = 0;
  let lastTime = 0;
  let pack = null;
  let tf = null;

  function collect(id) {
    const grp = svg.querySelector('[id="' + id + '"]');
    if (!grp) throw new Error('SVG 中没有找到分组：' + id);
    const out = [];
    for (const el of grp.querySelectorAll('path,line,rect,polygon,polyline,circle,ellipse')) {
      let len;
      try { len = el.getTotalLength(); } catch (e) { continue; }
      if (!Number.isFinite(len) || len < 0.1) continue;
      const m = el.getCTM();
      if (!m) continue;
      const scale = Math.max(Math.hypot(m.a, m.b), Math.hypot(m.c, m.d));
      const num = Math.min(900, Math.max(3, Math.ceil(len * scale / 4.2) + 1));
      const pts = [];
      for (let j = 0; j < num; j++) {
        const q = el.getPointAtLength(len * j / (num - 1));
        pts.push([q.x * m.a + q.y * m.c + m.e, q.x * m.b + q.y * m.d + m.f]);
      }
      out.push(pts);
    }
    return out;
  }

  function orderStrokes(strokes) {
    if (!strokes.length) return [];
    const unused = strokes.map(s => s.slice());
    let startIdx = 0, longest = -1;
    for (let i = 0; i < unused.length; i++) {
      let L = 0;
      const a = unused[i];
      for (let k = 1; k < a.length; k++) L += Math.hypot(a[k][0] - a[k - 1][0], a[k][1] - a[k - 1][1]);
      if (L > longest) { longest = L; startIdx = i; }
    }
    let current = unused.splice(startIdx, 1)[0];
    const result = [current];
    while (unused.length) {
      const p = current[current.length - 1];
      let best = 0, reverse = false, dMin = Infinity;
      for (let i = 0; i < unused.length; i++) {
        const a = unused[i];
        const p0 = a[0], p1 = a[a.length - 1];
        const d0 = (p[0] - p0[0]) ** 2 + (p[1] - p0[1]) ** 2;
        const d1 = (p[0] - p1[0]) ** 2 + (p[1] - p1[1]) ** 2;
        if (d0 < dMin) { best = i; reverse = false; dMin = d0; }
        if (d1 < dMin) { best = i; reverse = true; dMin = d1; }
      }
      current = unused.splice(best, 1)[0];
      if (reverse) current.reverse();
      result.push(current);
    }
    return result;
  }

  function concatPaths(strokes) {
    const points = [], draw = [];
    for (const s of strokes) {
      if (points.length) { points.push(s[0]); draw.push(false); }
      points.push(s[0]); draw.push(false);
      for (let j = 1; j < s.length; j++) { points.push(s[j]); draw.push(true); }
    }
    points.push(strokes[0][0]);
    draw.push(false);
    return { points, draw };
  }

  function resample(seq) {
    const { points, draw } = seq;
    const cum = new Float64Array(points.length);
    for (let i = 1; i < points.length; i++) {
      const L = Math.hypot(points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1]);
      cum[i] = cum[i - 1] + L * (draw[i] ? 1 : 0.20);
    }
    let j = 1;
    const re = new Float64Array(FFT_SAMPLES), im = new Float64Array(FFT_SAMPLES), ink = new Uint8Array(FFT_SAMPLES);
    const total = cum[cum.length - 1];
    for (let i = 0; i < FFT_SAMPLES; i++) {
      const d = (i / FFT_SAMPLES) * total;
      while (j < cum.length - 1 && cum[j] < d) j++;
      const seg = cum[j] - cum[j - 1];
      const a = seg > 1e-9 ? (d - cum[j - 1]) / seg : 0;
      const p0 = points[j - 1], p1 = points[j];
      re[i] = p0[0] + a * (p1[0] - p0[0]);
      im[i] = p0[1] + a * (p1[1] - p0[1]);
      ink[i] = draw[j] ? 1 : 0;
    }
    return { re, im, ink };
  }

  function fft(r, ii, inverse = false) {
    const n = r.length;
    for (let i = 1, j = 0; i < n; i++) {
      let b = n >> 1;
      for (; j & b; b >>= 1) j ^= b;
      j ^= b;
      if (i < j) {
        let t = r[i]; r[i] = r[j]; r[j] = t;
        t = ii[i]; ii[i] = ii[j]; ii[j] = t;
      }
    }
    for (let size = 2; size <= n; size *= 2) {
      const ang = (inverse ? 2 : -2) * Math.PI / size;
      const wr = Math.cos(ang), wi = Math.sin(ang);
      for (let base = 0; base < n; base += size) {
        let cr = 1, ci = 0;
        for (let j = 0; j < size / 2; j++) {
          const a = base + j, b = a + size / 2;
          const br = r[b] * cr - ii[b] * ci;
          const bi = r[b] * ci + ii[b] * cr;
          r[b] = r[a] - br; ii[b] = ii[a] - bi;
          r[a] += br; ii[a] += bi;
          const nr = cr * wr - ci * wi;
          ci = cr * wi + ci * wr;
          cr = nr;
        }
      }
    }
    if (inverse) {
      for (let i = 0; i < n; i++) { r[i] /= n; ii[i] /= n; }
    }
  }

  function makeChain(strokes) {
    const sampled = resample(concatPaths(orderStrokes(strokes)));
    const cr = sampled.re.slice(), ci = sampled.im.slice();
    fft(cr, ci);
    for (let j = 0; j < FFT_SAMPLES; j++) { cr[j] /= FFT_SAMPLES; ci[j] /= FFT_SAMPLES; }
    return { cr, ci, ink: sampled.ink, re: null, im: null, coef: [] };
  }

  function prepare(chain, K) {
    const r = new Float64Array(FFT_SAMPLES), im = new Float64Array(FFT_SAMPLES), coef = [];
    const freqs = [0];
    for (let f = 1; freqs.length < K; f++) { freqs.push(f); if (freqs.length < K) freqs.push(-f); }
    for (const f of freqs) {
      const k = f >= 0 ? f : FFT_SAMPLES + f;
      const x = chain.cr[k], y = chain.ci[k];
      r[k] = x; im[k] = y;
      coef.push({ f, x, y, amp: Math.hypot(x, y) });
    }
    fft(r, im, true);
    for (let i = 0; i < FFT_SAMPLES; i++) { r[i] *= FFT_SAMPLES; im[i] *= FFT_SAMPLES; }
    chain.re = r; chain.im = im; chain.coef = coef;
  }

  function tip(chain, t) {
    const discs = [];
    let x = 0, y = 0;
    for (const c of chain.coef) {
      const a = 2 * Math.PI * c.f * t;
      const co = Math.cos(a), si = Math.sin(a);
      const dx = c.x * co - c.y * si;
      const dy = c.x * si + c.y * co;
      discs.push({ x, y, r: c.amp, dx, dy });
      x += dx; y += dy;
    }
    return { x, y, discs };
  }

  function getTransform(chains) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const chain of chains) {
      for (let i = 0; i < FFT_SAMPLES; i++) {
        if (chain.re[i] < minX) minX = chain.re[i];
        if (chain.re[i] > maxX) maxX = chain.re[i];
        if (chain.im[i] < minY) minY = chain.im[i];
        if (chain.im[i] > maxY) maxY = chain.im[i];
      }
    }
    const sc = Math.min((canvas.width - 150) / (maxX - minX), (canvas.height - 80) / (maxY - minY));
    return { sc, ox: (canvas.width - (maxX - minX) * sc) / 2 - minX * sc, oy: (canvas.height - (maxY - minY) * sc) / 2 - minY * sc };
  }

  // Only visible segments are inked. Each new stroke begins at the previous point,
  // which prevents tiny gaps at pen-down transitions. Lifts never produce a line.
  function drawPath(chain, p, color) {
    if (p <= 0) return;
    const limit = Math.min(FFT_SAMPLES - 1, Math.floor(p * FFT_SAMPLES));
    const { sc, ox, oy } = tf;
    ctx.beginPath();
    let active = false;
    for (let i = 1; i <= limit; i++) {
      if (!chain.ink[i]) { active = false; continue; }
      if (!active) {
        ctx.moveTo(chain.re[i - 1] * sc + ox, chain.im[i - 1] * sc + oy);
        active = true;
      }
      ctx.lineTo(chain.re[i] * sc + ox, chain.im[i] * sc + oy);
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.9;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  // A single chain still contains all 3072 Fourier coefficients. Drawing the
  // visible circles in batches is far cheaper than stroke() per disc.
  function drawWheels(chain, p, penColor) {
    const T = tip(chain, p), { sc, ox, oy } = tf;
    ctx.beginPath();
    for (let i = 1; i < T.discs.length; i++) {
      const d = T.discs[i], r = d.r * sc;
      if (r < 1.15) continue;
      const cx = d.x * sc + ox, cy = d.y * sc + oy;
      ctx.moveTo(cx + r, cy);
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
    }
    ctx.strokeStyle = WHEEL_STROKE;
    ctx.lineWidth = 0.85;
    ctx.stroke();

    ctx.beginPath();
    for (let i = 1; i < T.discs.length; i++) {
      const d = T.discs[i], r = d.r * sc;
      if (r < 1.15) continue;
      const cx = d.x * sc + ox, cy = d.y * sc + oy;
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + d.dx * sc, cy + d.dy * sc);
    }
    ctx.strokeStyle = ARM_STROKE;
    ctx.lineWidth = 0.85;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(T.x * sc + ox, T.y * sc + oy, 3.6, 0, Math.PI * 2);
    ctx.fillStyle = penColor;
    ctx.fill();
  }

  function render() {
    if (!pack || !tf) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    drawPath(pack.building, progress, BUILDING_COLOR);
    drawPath(pack.stars, progress, STAR_COLOR);
    drawWheels(pack.building, progress, BUILDING_COLOR);
    drawWheels(pack.stars, progress, STAR_COLOR);
  }

  function updateUI() {
    seekEl.value = String(progress);
    percent.textContent = (progress * 100).toFixed(1) + '%';
    rateText.textContent = Number(rateEl.value).toFixed(1) + '×';
  }

  let tickPending = false;
  function scheduleFrame() {
    if (!tickPending) {
      tickPending = true;
      requestAnimationFrame(frame);
    }
  }

  function frame(time) {
    tickPending = false;
    if (!lastTime) lastTime = time;
    const delta = Math.min(100, Math.max(0, time - lastTime));
    lastTime = time;
    if (playing && pack) {
      progress = Math.min(1, progress + delta * Number(rateEl.value) / 40000);
      if (progress >= 1) {
        progress = 1;
        playing = false;
        playBtn.textContent = '播放';
      }
      updateUI();
    }
    render();
    if (playing) scheduleFrame();
  }

  playBtn.addEventListener('click', () => {
    if (!playing && progress >= 1) progress = 0;
    playing = !playing;
    playBtn.textContent = playing ? '暂停' : '播放';
    lastTime = 0;
    updateUI();
    scheduleFrame();
  });

  restartBtn.addEventListener('click', () => {
    progress = 0;
    playing = true;
    playBtn.textContent = '暂停';
    lastTime = 0;
    updateUI();
    scheduleFrame();
  });

  rateEl.addEventListener('input', updateUI);
  seekEl.addEventListener('input', () => {
    progress = Math.max(0, Math.min(1, Number(seekEl.value)));
    if (progress >= 1) {
      playing = false;
      playBtn.textContent = '播放';
    }
    lastTime = 0;
    updateUI();
    scheduleFrame();
  });

  try {
    if (!svg) throw new Error('未能解析内嵌 SVG');
    const building = collect('tiananmen-building');
    const stars = collect('five-stars');
    if (building.length < 5 || stars.length < 5) throw new Error('未提取到足够的城楼或五角星轮廓');
    pack = { building: makeChain(building), stars: makeChain(stars) };
    prepare(pack.building, HARMONICS);
    prepare(pack.stars, HARMONICS);
    tf = getTransform([pack.building, pack.stars]);
    status.textContent = `就绪：建筑 ${building.length} 段 / 星形 ${stars.length} 段 / 3072 谐波`;
    updateUI();
    window.tiananmenFourier = {ready:true, harmonicsPerChain:HARMONICS, chainCount:2, strokes:{building:building.length,stars:stars.length}, get progress(){return progress;}, get playing(){return playing;}};
    scheduleFrame();
  } catch (err) {
    errBox.style.display = 'block';
    errBox.textContent = '动画初始化失败：\n' + (err && err.stack ? err.stack : String(err));
    status.textContent = '初始化失败';
    console.error(err);
  }
})();
